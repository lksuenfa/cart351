CART351 Exercise 2
Leanne Suen Fa

Visualise content of a json file and filter through it
